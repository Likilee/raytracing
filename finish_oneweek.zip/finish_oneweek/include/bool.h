#ifndef BOOL_H
# define BOOL_H

# define FALSE 0
# define TRUE 1

typedef int		t_bool;

#endif
