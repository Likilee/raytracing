#ifndef CAMERA_H
# define CAMERA_H

#include "ray.h"

typedef struct	s_camera
{
	double			aspect_ratio;
	double			viewport_height;
	double			viewport_width;
	double			focal_length;
	t_point3		origin;
	t_vec3			horizontal;
	t_vec3			vertical;
	t_vec3			lower_left_corner;
	t_ray			r;
}				t_camera;

void	camera_set(t_camera *c);
t_ray	get_ray(double u, double v, t_camera *c);

#endif