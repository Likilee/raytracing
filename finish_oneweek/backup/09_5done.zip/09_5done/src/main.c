# include "main.h"
# include "bool.h"
# include "degree.h"
# include "ray.h"
# include "hittable.h"
# include "hittable_list.h"
# include "sphere.h"
# include "vec3.h"
# include "color.h"
# include "random.h"
# include "rtweekend.h"
# include "camera.h"
# include "material.h"

int	main(void)
{
	//Image
	const double	aspect_ratio = 16.0 / 9.0;
	const int		image_width = 1024;
	const int		image_height = (int)(image_width / aspect_ratio);
	const int		samples_per_pixel = 100;
	const int		max_depth = 50;

	//World
	t_hittable_list *world;
	t_material m_ground;
	t_material m_center;
	t_material m_left;
	t_material m_right;

	make_material(&m_ground, LAMBERTIAN, color(0.8, 0.8, 0.0));
	make_material(&m_center, LAMBERTIAN, color(0.7, 0.3, 0.3));
	make_material(&m_left, METAL, color(0.8, 0.8, 0.8));
	make_material(&m_right, METAL, color(0.8, 0.6, 0.2));

	world = NULL;
	h_lstadd_back(&world, h_lstnew(SP, new_sphere(point(0, -100.5, -1), 100, &m_ground)));
	h_lstadd_back(&world, h_lstnew(SP ,new_sphere(point(0, 0, -1), 0.5, &m_center)));
	h_lstadd_back(&world, h_lstnew(SP ,new_sphere(point(-1, 0, -1), 0.5, &m_left)));
	h_lstadd_back(&world, h_lstnew(SP ,new_sphere(point(1, 0, -1), 0.5, &m_right)));

	//Camera
	t_camera	cam;
	camera_set(&cam);

	int				i;
	int				j;
	int				k;
	t_color			pixel_color;
	double			u;
	double			v;
	t_ray			r;

	ft_printf("P3\n%d  %d\n255\n", image_width, image_height);
	// Render
	j = image_height - 1;
	while (j >= 0)
	{
		ft_putstr_fd("\rScanlines remaining: ", 2);
		ft_putnbr_fd(j, 2);
		ft_putchar_fd('\n', 2);
		i = 0;
		while (i < image_width)
		{
			k = 0;
			pixel_color = color(0, 0, 0);
			while (k++ < samples_per_pixel)
			{
				u = (i + random_double()) / (image_width - 1);
				v = (j + random_double()) / (image_height -1);
				r = get_ray(u, v, &cam);
				pixel_color = vplus(pixel_color, ray_color(&r, world, max_depth));
			}
			write_color(pixel_color, samples_per_pixel);
			++i;
		}
		--j;
	}
	ft_putstr_fd("Done.\n", 2);
}
