#include "camera.h"

void	camera_set(t_camera *c)
{
	c->aspect_ratio = 16.0 / 9.0;
	c->viewport_height = 2.0;
	c->viewport_width = c->aspect_ratio * c->viewport_height;
	c->focal_length = 1.0;
	c->origin = point(0, 0, 0);
	c->horizontal = vec3(c->viewport_width, 0, 0);
	c->vertical = vec3(0, c->viewport_height, 0);
	c->lower_left_corner = vminus(vminus(vminus(c->origin, vdevide(c->horizontal, 2)), vdevide(c->vertical, 2)), vec3(0, 0, c->focal_length));
};

t_ray	get_ray(double u, double v, t_camera *c)
{
	t_ray r;

	r.orig = c->origin;
	r.dir = vminus(vplus(vplus(c->lower_left_corner, vmult(c->horizontal, u)),
										 vmult(c->vertical, v)), c->origin);
	return (r);
}