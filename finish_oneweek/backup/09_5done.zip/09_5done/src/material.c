#include "material.h"

t_bool	scatter(t_ray *r_in, t_hit_record *rec, t_color *attenuation, t_ray * scattered)
{
	t_bool	result;

	if (rec->mat_ptr->mat_kind == LAMBERTIAN)
		result = scatter_lambertian(r_in, rec, attenuation, scattered);
	else if (rec->mat_ptr->mat_kind == METAL)
		result = scatter_metal(r_in, rec, attenuation, scattered);
	return (result);
}



t_bool	scatter_lambertian(t_ray *r_in, t_hit_record *rec, t_color *attenuation, t_ray * scattered)
{
	t_vec3 scatter_dir;

	scatter_dir = vplus(rec->normal, random_unit_vector());
	if (near_zero(&scatter_dir))
		scatter_dir = rec->normal;
	*scattered = ray(rec->p, scatter_dir);
	*attenuation = rec->mat_ptr->albedo;
	return (TRUE);
}

t_bool	scatter_metal(t_ray *r_in, t_hit_record *rec, t_color *attenuation, t_ray * scattered)
{
	t_vec3	reflected;

	reflected = reflect(vunit(r_in->dir), rec->normal);
	*scattered = ray(rec->p, reflected);
	*attenuation = rec->mat_ptr->albedo;
	return (vdot(scattered->dir, rec->normal) > 0);
}

void	make_material(t_material *mat, t_material_kind kind, t_color albedo)
{
	mat->mat_kind = kind;
	mat->albedo = albedo;
}
