#include "bvh.h"

// ㄴㅏ중에 동적할당 해제 체크해줘야함 메모리 릭!
t_bvh_node		*bvh_node(t_node_type type, t_object *objects, size_t start, size_t end, double time0, double time1)
{
	t_bvh_node	*node;
	int			axis = random_int(0,2);
	t_bool 		(*compare)();
	size_t		object_span;
	size_t		mid;
	t_object	**obj_ptr;
	t_aabb		box_left;
	t_aabb		box_right;
	t_object	*objects_itr;
	size_t		i;

	if (axis == 0)
		compare = box_x_compare;
	else if (axis == 1)
		compare = box_y_compare;
	else
		compare = box_z_compare;
	if(!(node = (t_bvh_node *)malloc(sizeof(t_bvh_node))))
		exit(0);
	object_span = end - start;
	if(!(obj_ptr = (t_object **)malloc(sizeof(t_object *) * object_span)))
		exit(0);
	i = 0;
	objects_itr = objects;
	while (i < end)
	{
		obj_ptr[i++] = objects_itr;
		objects_itr = objects_itr->next;
	}
	if (object_span == 1)
	{
		node->left = node->right = objects;
		node->l_type = node->r_type = HITABLE_LIST;
	}
	else if (object_span == 2)
	{
		if (compare(obj_ptr[start], obj_ptr[start + 1]))
		{
			node->left = obj_ptr[start];
			node->right = obj_ptr[start + 1];
			node->l_type = node->r_type = BVH;
		}
	}
	else
	{
		qsort(obj_ptr[start], object_span, sizeof(void *), compare);
		mid = start + object_span / 2;
		node->left = bvh_node(BVH, objects, start, mid, time0, time1);
		node->right = bvh_node(BVH, objects, mid, end, time0, time1);
	}
	if (!bounding_box(node->l_type, node->left, time0, time1, &box_left)
		|| !bounding_box(node->l_type, node->left, time0, time1, &box_right))
		perror("No bounding box int bvh_node constructor.\n");
	node->box = surrounding_box(box_left, box_right);
	return (node);
}

t_bool box_x_compare(const void *a, const void *b)
{
	t_aabb	box_a;
	t_aabb	box_b;

	if (!bounding_box(((t_object *)a)->type, ((t_object *)a)->data, 0, 0, &box_a)
		|| !bounding_box(((t_object *)b)->type, ((t_object *)b)->data, 0, 0, &box_a))
	perror("No bounding box in bvh_node constuctor.\n");
	return (box_a.min.x < box_b.min.x);
}

t_bool box_y_compare(const void *a, const void *b)
{
	t_aabb	box_a;
	t_aabb	box_b;

	if (!bounding_box(((t_object *)a)->type, ((t_object *)a)->data, 0, 0, &box_a)
		|| !bounding_box(((t_object *)b)->type, ((t_object *)b)->data, 0, 0, &box_a))
	perror("No bounding box in bvh_node constuctor.\n");
	return (box_a.min.y < box_b.min.y);
}

t_bool box_z_compare(const void *a, const void *b)
{
	t_aabb	box_a;
	t_aabb	box_b;

	if (!bounding_box(((t_object *)a)->type, ((t_object *)a)->data, 0, 0, &box_a)
		|| !bounding_box(((t_object *)b)->type, ((t_object *)b)->data, 0, 0, &box_a))
	perror("No bounding box in bvh_node constuctor.\n");
	return (box_a.min.z < box_b.min.z);
}
