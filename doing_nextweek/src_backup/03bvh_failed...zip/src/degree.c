#include "degree.h"

double	deg_to_rad(double degrees)
{
	return (degrees * M_PI / 180.0);
}