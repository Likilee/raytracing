#ifndef RTWEEKEND_H
# define RTWEEKEND_H

double	clamp(double x, double min, double max);

#endif