#ifndef BVH_H
# define BVH_H

# include "hittable.h"
# include "hittable_list.h"
# include "random.h"

# define BVH 11
# define HITABLE 12
# define HITABLE_LIST 21

typedef int	t_node_type;
typedef struct	s_linked_list t_object;
typedef struct	s_bvh_node
{
	t_aabb				box;
	t_node_type 		l_type;
	t_node_type			r_type;
	void 				*left;
	void				*right;
}				t_bvh_node;

t_bvh_node		*bvh_node(t_node_type type, t_object *objects, size_t start, size_t end, double time0, double time1);
t_bool box_x_compare(const void *a, const void *b);
t_bool box_y_compare(const void *a, const void *b);
t_bool box_z_compare(const void *a, const void *b);



#endif