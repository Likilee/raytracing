#ifndef MAIN_H
# define MAIN_H

# include "../src/libft/include/libft.h"
# include "../src/libft/include/get_next_line.h"
# include "../src/libft/include/libftprintf.h"
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>

#endif
