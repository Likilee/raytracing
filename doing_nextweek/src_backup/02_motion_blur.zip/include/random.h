#ifndef RANDOM_H
# define RANDOM_H

# include <stdlib.h>

double		random_double(void);
double		random_double_(double min, double max);

#endif