#ifndef DEGREE_H
# define DEGREE_H

#include <math.h>

double	deg_to_rad(double degrees);

#endif